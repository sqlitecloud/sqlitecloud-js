## Getting Started

This example shows how to use @sqlitecloud/drivers in plain Javascript

To run the example:

```bash
npm install
npm run start
```
